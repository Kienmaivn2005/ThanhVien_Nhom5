<?php

namespace App\Http\Controllers\Api\V1;
use Illuminate\Http\Request;
use App\Models\User;
use Illuminate\Support\Facades\Hash;
class AuthController
{
    //
    public function register(Request $request)
    {
            $request->validate([
                'username' => 'required|string',
                'name'     => 'required|string|max:255',
                'password' => 'required|min:6',
                'email'    => 'required|email',
            ]);
            $data = $request->all();
           
            // 👉 Kiểm tra username/email đã tồn tại
            if (User::where('username', $request->username)->exists()) {
                return response()->json(['message' => 'Tên đăng nhập đã tồn tại'], 409);
            }

            if (User::where('email', $request->email)->exists()) {
                return response()->json(['message' => 'Email đã được sử dụng'], 409);
            }

            // 👉 Tạo user
            $user = User::create([
                'username' => $request->username,
                'name'     => $request->name,
                'email'    => $request->email,
                'password' => Hash::make($request->password),
            ]);

            return response()->json([
                'token' => $user->createToken('api-token')->accessToken
            ]);
            
    }
    public function login(Request $request)
    {
       
        $request->validate([
            'username' => 'required|string',
            'password' => 'required|string',
        ]);

        $user = User::where('username', $request->username)->first();

        if (! $user || ! Hash::check($request->password, $user->password)) {
            return response()->json([
                'message' => 'Tên đăng nhập hoặc mật khẩu không đúng'
            ], 401);
        }

        // Tạo access token bằng Passport
        $token = $user->createToken('api-token')->accessToken;

        return response()->json([
            'token' => $token
        ]);
    }
}